import React, { useState } from "react";
import {
  Activity,
  HeartPulse,
  Pill,
  ShieldAlert,
  ArrowRight,
  ArrowLeft,
} from "lucide-react";

import FormField from "../../components/forms/FormField";
import SectionCard from "../../components/forms/SectionCard";
import ProgressSteps from "../../components/forms/ProgressSteps";

const initialClinicalData = {
  chiefComplaint: "",
  symptomDuration: "",
  symptomSeverity: "",
  symptoms: "",
  existingConditions: "",
  currentMedicines: "",
  allergies: "",
  previousSurgeries: "",
  familyHistory: "",
  smoking: "",
  alcohol: "",
};

function ClinicalIntake({ patientData, onNext, onBack }) {
  const [form, setForm] = useState(initialClinicalData);
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;

    setForm((previous) => ({
      ...previous,
      [name]: value,
    }));

    setErrors((previous) => ({
      ...previous,
      [name]: "",
    }));
  };

  const validate = () => {
    const nextErrors = {};

    if (!form.chiefComplaint.trim()) {
      nextErrors.chiefComplaint =
        "Please describe the main health concern.";
    }

    if (!form.symptomDuration) {
      nextErrors.symptomDuration =
        "Please select symptom duration.";
    }

    if (!form.symptomSeverity) {
      nextErrors.symptomSeverity =
        "Please select symptom severity.";
    }

    if (!form.symptoms.trim()) {
      nextErrors.symptoms =
        "Please describe the symptoms.";
    }

    setErrors(nextErrors);

    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!validate()) {
      return;
    }

    onNext({
      ...patientData,
      clinical: form,
    });
  };

  return (
    <div className="page-container form-page">
      <div className="form-page-header">
        <div>
          <span className="card-eyebrow">
            CLINICAL INTAKE
          </span>

          <h1>Health Information</h1>

          <p>
            Tell us about the current health concern and
            relevant medical history.
          </p>
        </div>
      </div>

      <ProgressSteps currentStep={2} />

      <form onSubmit={handleSubmit}>
        <SectionCard
          icon={<Activity size={21} />}
          title="Current Health Concern"
          description="Describe what brought you to MediKiosk today."
        >
          <div className="form-grid">
            <FormField
              label="Main Health Concern"
              name="chiefComplaint"
              type="textarea"
              value={form.chiefComplaint}
              onChange={handleChange}
              placeholder="Example: fever, headache, stomach discomfort..."
              required
              error={errors.chiefComplaint}
            />

            <div />

            <FormField
              label="How long have you had this concern?"
              name="symptomDuration"
              type="select"
              value={form.symptomDuration}
              onChange={handleChange}
              required
              error={errors.symptomDuration}
              options={[
                { value: "today", label: "Started today" },
                { value: "1-3-days", label: "1–3 days" },
                { value: "4-7-days", label: "4–7 days" },
                { value: "1-2-weeks", label: "1–2 weeks" },
                { value: "more-than-2-weeks", label: "More than 2 weeks" },
                { value: "long-term", label: "Long-term / recurring" },
              ]}
            />

            <FormField
              label="How severe is it?"
              name="symptomSeverity"
              type="select"
              value={form.symptomSeverity}
              onChange={handleChange}
              required
              error={errors.symptomSeverity}
              options={[
                { value: "mild", label: "Mild" },
                { value: "moderate", label: "Moderate" },
                { value: "severe", label: "Severe" },
                {
                  value: "very-severe",
                  label: "Very severe",
                },
              ]}
            />

            <FormField
              label="Symptoms"
              name="symptoms"
              type="textarea"
              value={form.symptoms}
              onChange={handleChange}
              placeholder="Describe the symptoms you are experiencing."
              required
              error={errors.symptoms}
            />
          </div>
        </SectionCard>

        <SectionCard
          icon={<HeartPulse size={21} />}
          title="Medical History"
          description="This information helps create a more complete clinical record."
        >
          <div className="form-grid">
            <FormField
              label="Existing Medical Conditions"
              name="existingConditions"
              type="textarea"
              value={form.existingConditions}
              onChange={handleChange}
              placeholder="Example: diabetes, asthma, hypertension, none..."
            />

            <FormField
              label="Previous Surgeries / Procedures"
              name="previousSurgeries"
              type="textarea"
              value={form.previousSurgeries}
              onChange={handleChange}
              placeholder="Mention relevant previous procedures or write 'None'."
            />

            <FormField
              label="Family Medical History"
              name="familyHistory"
              type="textarea"
              value={form.familyHistory}
              onChange={handleChange}
              placeholder="Mention important family health conditions."
            />
          </div>
        </SectionCard>

        <SectionCard
          icon={<Pill size={21} />}
          title="Medications & Allergies"
          description="List medicines and allergies that healthcare professionals should know about."
        >
          <div className="form-grid">
            <FormField
              label="Current Medicines"
              name="currentMedicines"
              type="textarea"
              value={form.currentMedicines}
              onChange={handleChange}
              placeholder="Medicine name, dose if known, and frequency."
            />

            <FormField
              label="Known Allergies"
              name="allergies"
              type="textarea"
              value={form.allergies}
              onChange={handleChange}
              placeholder="Medicines, foods or other known allergies."
            />
          </div>
        </SectionCard>

        <SectionCard
          icon={<ShieldAlert size={21} />}
          title="Lifestyle Information"
          description="Optional information that may help during clinical review."
        >
          <div className="form-grid">
            <FormField
              label="Smoking"
              name="smoking"
              type="select"
              value={form.smoking}
              onChange={handleChange}
              options={[
                { value: "never", label: "Never" },
                { value: "former", label: "Former smoker" },
                { value: "current", label: "Currently smoke" },
                { value: "unknown", label: "Prefer not to say" },
              ]}
            />

            <FormField
              label="Alcohol"
              name="alcohol"
              type="select"
              value={form.alcohol}
              onChange={handleChange}
              options={[
                { value: "never", label: "Never" },
                { value: "former", label: "Previously used" },
                { value: "current", label: "Currently use" },
                { value: "unknown", label: "Prefer not to say" },
              ]}
            />
          </div>
        </SectionCard>

        <div className="form-actions">
          <button
            type="button"
            className="button button-secondary"
            onClick={onBack}
          >
            <ArrowLeft size={17} />
            Back
          </button>

          <button
            type="submit"
            className="button button-primary"
          >
            Continue to Review
            <ArrowRight size={17} />
          </button>
        </div>
      </form>
    </div>
  );
}

export default ClinicalIntake;