from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
import sqlite3
import os
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "ayush-care-secret-key"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE_DIR, "ayush_care.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {
    "pdf", "png", "jpg", "jpeg", "webp", "doc", "docx"
}


def get_db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower()
        in ALLOWED_EXTENSIONS
    )


def init_db():

    con = get_db()

    con.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'patient',
            created_at TEXT NOT NULL
        )
    """)

    con.execute("""
        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            name TEXT,
            age INTEGER,
            gender TEXT,
            phone TEXT,
            address TEXT,
            blood_group TEXT,
            symptoms TEXT,
            history TEXT,
            medicines TEXT,
            allergies TEXT,
            notes TEXT,
            summary TEXT
        )
    """)

    con.execute("""
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            filename TEXT NOT NULL,
            uploaded_at TEXT NOT NULL
        )
    """)

    con.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            doctor_name TEXT NOT NULL,
            appointment_date TEXT NOT NULL,
            appointment_time TEXT NOT NULL,
            reason TEXT,
            status TEXT DEFAULT 'Pending'
        )
    """)

    con.execute("""
        CREATE TABLE IF NOT EXISTS consultations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            doctor_name TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    doctor = con.execute(
        "SELECT id FROM users WHERE email=?",
        ("doctor@ayush.local",)
    ).fetchone()

    if not doctor:
        con.execute("""
            INSERT INTO users
            (name, email, password, role, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            "AYUSH Doctor",
            "doctor@ayush.local",
            generate_password_hash("doctor123"),
            "doctor",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ))

    con.commit()
    con.close()


def login_required():
    return "user_id" in session


@app.route("/")
def home():

    if "user_id" in session:

        if session.get("role") == "doctor":
            return redirect(url_for("doctor_dashboard"))

        return redirect(url_for("dashboard"))

    return render_template("home.html")


@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or not password:
            flash("Please fill all fields.", "error")
            return redirect(url_for("register"))

        con = get_db()

        existing = con.execute(
            "SELECT id FROM users WHERE email=?",
            (email,)
        ).fetchone()

        if existing:
            con.close()
            flash("Email already registered.", "error")
            return redirect(url_for("register"))

        cur = con.execute("""
            INSERT INTO users
            (name, email, password, role, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            name,
            email,
            generate_password_hash(password),
            "patient",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ))

        user_id = cur.lastrowid

        con.execute("""
            INSERT INTO patients
            (user_id, name)
            VALUES (?, ?)
        """, (user_id, name))

        con.commit()
        con.close()

        flash("Registration successful. Please login.", "success")

        return redirect(url_for("login"))

    return render_template("register.html")
@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        con = get_db()

        user = con.execute(
            "SELECT * FROM users WHERE email=?",
            (email,)
        ).fetchone()

        con.close()

        if not user or not check_password_hash(user["password"], password):
            flash("Invalid email or password.", "error")
            return redirect(url_for("login"))

        session["user_id"] = user["id"]
        session["name"] = user["name"]
        session["role"] = user["role"]

        if user["role"] == "doctor":
            return redirect(url_for("dashboard"))

        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
def logout():

    session.clear()

    flash("You have been logged out.", "success")

    return redirect(url_for("home"))


@app.route("/dashboard")
def dashboard():

    if not login_required():
        return redirect(url_for("login"))

    if session.get("role") == "doctor":
        return redirect(url_for("doctor_dashboard"))

    con = get_db()

    patient = con.execute("""
        SELECT *
        FROM patients
        WHERE user_id=?
    """, (session["user_id"],)).fetchone()

    reports = con.execute("""
        SELECT *
        FROM reports
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient["id"],)).fetchall()

    appointments = con.execute("""
        SELECT *
        FROM appointments
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient["id"],)).fetchall()

    consultations = con.execute("""
        SELECT *
        FROM consultations
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient["id"],)).fetchall()

    con.close()

    return render_template(
        "dashboard.html",
        patient=patient,
        reports=reports,
        appointments=appointments,
        consultations=consultations
    )


@app.route("/profile", methods=["GET", "POST"])
def profile():

    if not login_required():
        return redirect(url_for("login"))

    con = get_db()

    patient = con.execute("""
        SELECT *
        FROM patients
        WHERE user_id=?
    """, (session["user_id"],)).fetchone()

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        age = request.form.get("age", "").strip()
        gender = request.form.get("gender", "").strip()
        phone = request.form.get("phone", "").strip()
        address = request.form.get("address", "").strip()
        blood_group = request.form.get("blood_group", "").strip()

        symptoms = request.form.get("symptoms", "").strip()
        history = request.form.get("history", "").strip()
        medicines = request.form.get("medicines", "").strip()
        allergies = request.form.get("allergies", "").strip()
        notes = request.form.get("notes", "").strip()
        summary = request.form.get("summary", "").strip()

        con.execute("""
            UPDATE patients
            SET
                name=?,
                age=?,
                gender=?,
                phone=?,
                address=?,
                blood_group=?,
                symptoms=?,
                history=?,
                medicines=?,
                allergies=?,
                notes=?,
                summary=?
            WHERE user_id=?
        """, (
            name,
            age if age else None,
            gender,
            phone,
            address,
            blood_group,
            symptoms,
            history,
            medicines,
            allergies,
            notes,
            summary,
            session["user_id"]
        ))

        con.execute("""
            UPDATE users
            SET name=?
            WHERE id=?
        """, (name, session["user_id"]))

        con.commit()

        session["name"] = name

        flash("Profile and medical information saved.", "success")

        patient = con.execute("""
            SELECT *
            FROM patients
            WHERE user_id=?
        """, (session["user_id"],)).fetchone()

    con.close()

    return render_template(
        "profile.html",
        patient=patient
    )
@app.route("/medical-records")
def medical_records():
    if not login_required():
        return redirect(url_for("login"))

    con = get_db()

    patient = con.execute("""
        SELECT *
        FROM patients
        WHERE user_id=?
    """, (session["user_id"],)).fetchone()

    if not patient:
        con.close()
        return "Patient record not found", 404

    reports = con.execute("""
        SELECT *
        FROM reports
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient["id"],)).fetchall()

    appointments = con.execute("""
        SELECT *
        FROM appointments
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient["id"],)).fetchall()

    consultations = con.execute("""
        SELECT *
        FROM consultations
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient["id"],)).fetchall()

    con.close()

    return render_template(
        "medical_records.html",
        patient=patient,
        reports=reports,
        appointments=appointments,
        consultations=consultations
    )


@app.route("/reports", methods=["GET", "POST"])
def reports():

    if not login_required():
        return redirect(url_for("login"))

    con = get_db()

    patient = con.execute("""
        SELECT *
        FROM patients
        WHERE user_id=?
    """, (session["user_id"],)).fetchone()

    if request.method == "POST":

        title = request.form.get("title", "").strip()
        file = request.files.get("report")

        if not title:
            flash("Enter report title.", "error")

        elif not file or file.filename == "":
            flash("Please select a report file.", "error")

        elif not allowed_file(file.filename):
            flash("File type not allowed.", "error")

        else:

            original = secure_filename(file.filename)

            filename = (
                str(patient["id"])
                + "_"
                + datetime.now().strftime("%Y%m%d%H%M%S")
                + "_"
                + original
            )

            file.save(
                os.path.join(UPLOAD_FOLDER, filename)
            )

            con.execute("""
                INSERT INTO reports
                (patient_id, title, filename, uploaded_at)
                VALUES (?, ?, ?, ?)
            """, (
                patient["id"],
                title,
                filename,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))

            con.commit()

            flash("Report uploaded successfully.", "success")

    report_list = con.execute("""
        SELECT *
        FROM reports
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient["id"],)).fetchall()

    con.close()

    return render_template(
        "reports.html",
        reports=report_list
    )


@app.route("/report/<int:report_id>")
def open_report(report_id):

    if not login_required():
        return redirect(url_for("login"))

    con = get_db()

    report = con.execute("""
        SELECT r.*
        FROM reports r
        JOIN patients p
        ON r.patient_id = p.id
        WHERE r.id=? AND p.user_id=?
    """, (
        report_id,
        session["user_id"]
    )).fetchone()

    con.close()

    if not report:
        return "Report not found", 404

    return send_from_directory(
        UPLOAD_FOLDER,
        report["filename"]
    )


@app.route("/report/<int:report_id>/download")
def download_report(report_id):

    if not login_required():
        return redirect(url_for("login"))

    con = get_db()

    report = con.execute("""
        SELECT r.*
        FROM reports r
        JOIN patients p
        ON r.patient_id = p.id
        WHERE r.id=? AND p.user_id=?
    """, (
        report_id,
        session["user_id"]
    )).fetchone()

    con.close()

    if not report:
        return "Report not found", 404

    return send_from_directory(
        UPLOAD_FOLDER,
        report["filename"],
        as_attachment=True
    )
@app.route("/appointments", methods=["GET", "POST"])
def appointments():

    if not login_required():
        return redirect(url_for("login"))

    con = get_db()

    patient = con.execute(
        "SELECT * FROM patients WHERE user_id=?",
        (session["user_id"],)
    ).fetchone()

    if request.method == "POST":

        doctor_name = request.form.get("doctor_name", "AYUSH Doctor").strip()
        appointment_date = request.form.get("appointment_date", "").strip()
        appointment_time = request.form.get("appointment_time", "").strip()
        reason = request.form.get("reason", "").strip()

        if not appointment_date or not appointment_time:
            flash("Please select date and time.", "error")
        else:
            con.execute("""
                INSERT INTO appointments
                (patient_id, doctor_name, appointment_date,
                 appointment_time, reason, status)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                patient["id"],
                doctor_name,
                appointment_date,
                appointment_time,
                reason,
                "Pending"
            ))

            con.commit()
            flash("Appointment booked successfully.", "success")

    appointment_list = con.execute("""
        SELECT *
        FROM appointments
        WHERE patient_id=?
        ORDER BY appointment_date DESC, appointment_time DESC
    """, (patient["id"],)).fetchall()

    con.close()

    return render_template(
        "appointments.html",
        appointments=appointment_list
    )


@app.route("/consultations", methods=["GET", "POST"])
def consultations():

    if not login_required():
        return redirect(url_for("login"))

    con = get_db()

    patient = con.execute(
        "SELECT * FROM patients WHERE user_id=?",
        (session["user_id"],)
    ).fetchone()

    if request.method == "POST":

        message = request.form.get("message", "").strip()

        if not message:
            flash("Please write your message.", "error")
        else:

            con.execute("""
                INSERT INTO consultations
                (patient_id, doctor_name, message, created_at)
                VALUES (?, ?, ?, ?)
            """, (
                patient["id"],
                "AYUSH Doctor",
                message,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))

            con.commit()

            flash("Consultation message sent successfully.", "success")

    consultation_list = con.execute("""
        SELECT *
        FROM consultations
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient["id"],)).fetchall()

    con.close()

    return render_template(
        "consultations.html",
        consultations=consultation_list
    )


@app.route("/assistant", methods=["GET", "POST"])
def assistant():

    if not login_required():
        return redirect(url_for("login"))

    answer = None

    if request.method == "POST":

        question = request.form.get("question", "").lower().strip()

        if "fever" in question or "bukhar" in question:
            answer = (
                "For fever, keep yourself hydrated and take adequate rest. "
                "If fever is high, persistent, or accompanied by serious symptoms, "
                "consult a qualified doctor."
            )

        elif "headache" in question or "sir dard" in question:
            answer = (
                "For a mild headache, rest, hydration and proper sleep may help. "
                "If headache is severe, sudden, or recurring, consult a doctor."
            )

        elif "cold" in question or "cough" in question:
            answer = (
                "Stay hydrated, rest properly and avoid smoke or other irritants. "
                "Persistent or severe symptoms should be evaluated by a doctor."
            )

        elif "medicine" in question or "dawai" in question:
            answer = (
                "Do not start or stop prescription medicines based only on this "
                "assistant. Please consult a qualified healthcare professional."
            )

        else:
            answer = (
                "I can provide basic health information, but I cannot diagnose "
                "medical conditions. For serious or persistent symptoms, please "
                "consult a qualified doctor."
            )

    return render_template(
        "assistant.html",
        answer=answer
    )


@app.route("/emergency")
def emergency():

    if not login_required():
        return redirect(url_for("login"))

    return render_template("emergency.html")


@app.route("/maps")
def maps():

    if not login_required():
        return redirect(url_for("login"))

    return render_template("maps.html")

@app.route("/doctor")
def doctor_dashboard():
    if not login_required():
        return redirect(url_for("login"))

    if session.get("role") != "doctor":
        return redirect(url_for("dashboard"))

    con = get_db()

    patients = con.execute("""
        SELECT *
        FROM patients
        ORDER BY id DESC
    """).fetchall()

    appointments = con.execute("""
        SELECT
            a.*,
            p.name AS patient_name
        FROM appointments a
        JOIN patients p
        ON a.patient_id = p.id
        ORDER BY a.appointment_date ASC,
                 a.appointment_time ASC
    """).fetchall()

    reports = con.execute("""
        SELECT
            r.*,
            p.name AS patient_name
        FROM reports r
        JOIN patients p
        ON r.patient_id = p.id
        ORDER BY r.id DESC
    """).fetchall()

    con.close()

    return render_template(
        "doctor_dashboard.html",
        patients=patients,
        appointments=appointments,
        reports=reports
    )
@app.route("/doctor/patient/<int:patient_id>")
def doctor_patient(patient_id):
    if not login_required():
        return redirect(url_for("login"))

    if session.get("role") != "doctor":
        return redirect(url_for("dashboard"))

    con = get_db()

    patient = con.execute("""
        SELECT *
        FROM patients
        WHERE id=?
    """, (patient_id,)).fetchone()

    if not patient:
        con.close()
        return "Patient not found", 404

    reports = con.execute("""
        SELECT *
        FROM reports
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient_id,)).fetchall()

    appointments = con.execute("""
        SELECT *
        FROM appointments
        WHERE patient_id=?
        ORDER BY appointment_date DESC,
                 appointment_time DESC
    """, (patient_id,)).fetchall()

    consultations = con.execute("""
        SELECT *
        FROM consultations
        WHERE patient_id=?
        ORDER BY id DESC
    """, (patient_id,)).fetchall()

    con.close()

    return render_template(
        "doctor_patient.html",
        patient=patient,
        reports=reports,
        appointments=appointments,
        consultations=consultations
    )


@app.errorhandler(404)
def page_not_found(error):

    return render_template(
        "error.html",
        code=404,
        message="Page not found."
    ), 404


@app.errorhandler(500)
def internal_error(error):

    return render_template(
        "error.html",
        code=500,
        message="Something went wrong."
    ), 500


# ---------------- START APPLICATION ----------------
 
init_db()

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )